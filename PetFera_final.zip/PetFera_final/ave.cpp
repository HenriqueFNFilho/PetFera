#include "animal.hpp"
#include "ave.hpp"
#include<iostream>
#include<fstream>
#include<iomanip>

using std::cin;
using std::cout;
using std::ios;
using std::setfill;
using std::setw;




//Implementação da classe Ave

Ave::Ave(){}

Ave::Ave(int id, tipoAnimal tipo, string nome, string genero, int idade, string cor, bool voando): Animal(id, tipo, nome, genero, idade), cor(cor), voando(voando){}


Ave::~Ave(){}

string Ave::getCor(){
    return this->cor;
}
void Ave::setCor(string cor){
    this->cor = cor;
}
bool Ave::getVoando(){
    return this->voando;
}
void Ave::setVoando(bool voando){
    this->voando = voando;
}
vector<shared_ptr<Ave>> Ave::getAve(){
	return this->ave;
}


/*
void Ave::criarAve(){
	int cAve_id;
    string cAve_nome;
    int cAve_idade;
    string cAve_genero;
	string cAve_cor;
	bool cAve_voando;
    int aux = 1;
	char letra = 'n';

    do{
    cout << "Id: ";
    cin >> cAve_id;
    cout << "Nome: ";
    cin >> cAve_nome;
    cout << "Idade: ";
	cin >> cAve_idade;
	cout << "Genero: ";
	cin >> cAve_genero;
	cout << "Cor: ";
	cin >> cAve_cor;
	cout << "Apta a voar? - S/s(sim) - N/n(não): ";
	cin >> letra;
	if(letra == 'S' || letra == 's'){
        cAve_voando = true;
    }
    else if (letra == 'N' || letra == 'n')    {
        cAve_voando = false;
    }
	else{
		cout << "valor incorreto" << endl;
	}
	
	

    
    shared_ptr<Ave> criado = make_shared<Ave>(cAve_id, cAve_nome, cAve_genero, cAve_idade, cAve_cor, cAve_voando);

    this->inserirAve(criado);

    cout << "[1]Inserir outro, [0]Sair:  ";
    cin >> aux;

    }while(aux == 1);
}
*/

/*
void Ave::removeAve(string nome){
	int y = ave.size();
     for(int x = 0; x < (y-1); x++){
         if(this->ave.at(x)->getNome() == nome){
            this->ave.erase(this->ave.begin()+x);
         }
     }
}

void Ave::inserirAve(shared_ptr<Ave> novo){
	this->ave.push_back(novo);
}
*/

/*
void Ave::gravaAve(){
	fstream arquivo("arqAve.txt",ios::in | ios::out | ios::app);
	for(auto& x: this->ave){
		arquivo << x->getId() << "-" << x->getNome() << "-" << x->getGenero()
		<< "-" << x->getIdade() << "-" << x->getCor() << "-" << x->getVoando() << endl;
	}
	arquivo.close();
}
*/

/*
void Ave::lerAve(){
    fstream arquivo;
	string linha;
	arquivo.open("arqAve.txt",ios::in);    
    if(arquivo.is_open()){
    	while(getline(arquivo,linha, '-')){
    		cout << linha << endl;
    	}
    }
	arquivo.close();
}
*/

/*
void Ave::listarAve(){
	cout << setfill (' ') << setw (5) << "ID" << " | " 
		<< setfill ('.') << setw (30) << "Nome" << " | " 
		<< setfill (' ') << setw (5) << "Idade" << " | "
		<< setfill (' ') << setw (15) << "Genero" << " | " 
		<< setfill (' ') << setw (15) << "Cor" << " | " 
		<< setfill (' ') << setw (15) << "Voando" << endl;
    for(auto& x: this->ave){
        cout << *x;
    }
}
*/

/*
ostream& 
operator<< (ostream &o, Ave& ave){
    string strVoando = (ave.voando == true) ? "Sim" : "Nao";
	o << setfill (' ') << setw (5) << ave.getId() << " | " 
		<< setfill ('.') << setw (30) << ave.getNome() << " | " 
		<< setfill (' ') << setw (5) << ave.getIdade() << " | "
		<< setfill (' ') << setw (15) << ave.getGenero() << " | " 
		<< setfill (' ') << setw (15) << ave.getCor() <<" | " 
		<< setfill (' ') << setw (15) << strVoando << endl;
	return o;
}
*/